using System.Runtime.CompilerServices;

namespace POS_Client
{
	internal class RegisterObject
	{
		[CompilerGenerated]
		private string _003Clicense_003Ek__BackingField;

		[CompilerGenerated]
		private string _003Cname_003Ek__BackingField;

		[CompilerGenerated]
		private string _003ChddSerialId_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CapplyTime_003Ek__BackingField;

		public string license
		{
			[CompilerGenerated]
			get
			{
				return _003Clicense_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Clicense_003Ek__BackingField = value;
			}
		}

		public string name
		{
			[CompilerGenerated]
			get
			{
				return _003Cname_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Cname_003Ek__BackingField = value;
			}
		}

		public string hddSerialId
		{
			[CompilerGenerated]
			get
			{
				return _003ChddSerialId_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003ChddSerialId_003Ek__BackingField = value;
			}
		}

		public string applyTime
		{
			[CompilerGenerated]
			get
			{
				return _003CapplyTime_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CapplyTime_003Ek__BackingField = value;
			}
		}
	}
}
