using System.Runtime.CompilerServices;

namespace POS_Client
{
	internal class AuthResultObject
	{
		[CompilerGenerated]
		private string _003CinUse_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CerrorCode_003Ek__BackingField;

		[CompilerGenerated]
		private string _003Cmessage_003Ek__BackingField;

		[CompilerGenerated]
		private string _003Cserial_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CshopType_003Ek__BackingField;

		public string inUse
		{
			[CompilerGenerated]
			get
			{
				return _003CinUse_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CinUse_003Ek__BackingField = value;
			}
		}

		public string errorCode
		{
			[CompilerGenerated]
			get
			{
				return _003CerrorCode_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CerrorCode_003Ek__BackingField = value;
			}
		}

		public string message
		{
			[CompilerGenerated]
			get
			{
				return _003Cmessage_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Cmessage_003Ek__BackingField = value;
			}
		}

		public string serial
		{
			[CompilerGenerated]
			get
			{
				return _003Cserial_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Cserial_003Ek__BackingField = value;
			}
		}

		public string shopType
		{
			[CompilerGenerated]
			get
			{
				return _003CshopType_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CshopType_003Ek__BackingField = value;
			}
		}
	}
}
