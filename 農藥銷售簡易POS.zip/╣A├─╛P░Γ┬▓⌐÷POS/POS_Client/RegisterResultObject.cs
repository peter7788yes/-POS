using System.Runtime.CompilerServices;

namespace POS_Client
{
	internal class RegisterResultObject
	{
		[CompilerGenerated]
		private string _003CisSuccess_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CerrorCode_003Ek__BackingField;

		[CompilerGenerated]
		private string _003Cmessage_003Ek__BackingField;

		public string isSuccess
		{
			[CompilerGenerated]
			get
			{
				return _003CisSuccess_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CisSuccess_003Ek__BackingField = value;
			}
		}

		public string errorCode
		{
			[CompilerGenerated]
			get
			{
				return _003CerrorCode_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CerrorCode_003Ek__BackingField = value;
			}
		}

		public string message
		{
			[CompilerGenerated]
			get
			{
				return _003Cmessage_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Cmessage_003Ek__BackingField = value;
			}
		}
	}
}
