namespace POS_Client
{
	internal class vendorInfo
	{
		public string SupplierNo;

		public string SupplierName;

		public string SupplierIdNo;

		public string vendorId;

		public string vendorName;
	}
}
