namespace POS_Client
{
	public enum SystemModeType
	{
		簡易版,
		呈報版
	}
}
