using System.Runtime.CompilerServices;

namespace POS_Client
{
	public class HyScopeInfo
	{
		[CompilerGenerated]
		private string _003CpesticideId_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CformCode_003Ek__BackingField;

		[CompilerGenerated]
		private string _003Ccontents_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CcropId_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CcropName_003Ek__BackingField;

		public string pesticideId
		{
			[CompilerGenerated]
			get
			{
				return _003CpesticideId_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CpesticideId_003Ek__BackingField = value;
			}
		}

		public string formCode
		{
			[CompilerGenerated]
			get
			{
				return _003CformCode_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CformCode_003Ek__BackingField = value;
			}
		}

		public string contents
		{
			[CompilerGenerated]
			get
			{
				return _003Ccontents_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Ccontents_003Ek__BackingField = value;
			}
		}

		public string cropId
		{
			[CompilerGenerated]
			get
			{
				return _003CcropId_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CcropId_003Ek__BackingField = value;
			}
		}

		public string cropName
		{
			[CompilerGenerated]
			get
			{
				return _003CcropName_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CcropName_003Ek__BackingField = value;
			}
		}
	}
}
