namespace POS_Client
{
	public enum RoleType
	{
		凌網管理員 = -1,
		管理員,
		銷售員
	}
}
