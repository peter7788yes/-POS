using System.CodeDom.Compiler;

namespace POS_Client.POS_WS_Auth
{
	[GeneratedCode("System.Web.Services", "4.7.2053.0")]
	public delegate void toRestoreCompletedEventHandler(object sender, toRestoreCompletedEventArgs e);
}
