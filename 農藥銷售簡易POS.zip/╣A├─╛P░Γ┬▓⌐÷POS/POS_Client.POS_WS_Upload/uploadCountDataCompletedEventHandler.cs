using System.CodeDom.Compiler;

namespace POS_Client.POS_WS_Upload
{
	[GeneratedCode("System.Web.Services", "4.7.2053.0")]
	public delegate void uploadCountDataCompletedEventHandler(object sender, uploadCountDataCompletedEventArgs e);
}
