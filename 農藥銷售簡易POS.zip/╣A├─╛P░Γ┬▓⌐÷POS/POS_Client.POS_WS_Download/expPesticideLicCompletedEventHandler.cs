using System.CodeDom.Compiler;

namespace POS_Client.POS_WS_Download
{
	[GeneratedCode("System.Web.Services", "4.6.1055.0")]
	public delegate void expPesticideLicCompletedEventHandler(object sender, expPesticideLicCompletedEventArgs e);
}
