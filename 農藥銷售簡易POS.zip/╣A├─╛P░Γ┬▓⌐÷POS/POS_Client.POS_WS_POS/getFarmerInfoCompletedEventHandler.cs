using System.CodeDom.Compiler;

namespace POS_Client.POS_WS_POS
{
	[GeneratedCode("System.Web.Services", "4.6.1055.0")]
	public delegate void getFarmerInfoCompletedEventHandler(object sender, getFarmerInfoCompletedEventArgs e);
}
