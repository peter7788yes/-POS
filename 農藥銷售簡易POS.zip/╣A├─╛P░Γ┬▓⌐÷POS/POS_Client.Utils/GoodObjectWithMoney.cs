using System.Runtime.CompilerServices;

namespace POS_Client.Utils
{
	public class GoodObjectWithMoney
	{
		[CompilerGenerated]
		private int _003C_index_003Ek__BackingField;

		[CompilerGenerated]
		private CommodityInfo _003C_GDSName_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_setprice_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_sellingprice_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_number_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_subtotal_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_discount_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_sum_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_barcode_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_cropId_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_pestId_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_specialPrice1_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_specialPrice2_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_openPrice_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_subsidyMoney_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_subsidyFertilizer_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_ISWS_003Ek__BackingField;

		[CompilerGenerated]
		private string _003C_CLA1NO_003Ek__BackingField;

		public int _index
		{
			[CompilerGenerated]
			get
			{
				return _003C_index_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_index_003Ek__BackingField = value;
			}
		}

		public CommodityInfo _GDSName
		{
			[CompilerGenerated]
			get
			{
				return _003C_GDSName_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_GDSName_003Ek__BackingField = value;
			}
		}

		public string _setprice
		{
			[CompilerGenerated]
			get
			{
				return _003C_setprice_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_setprice_003Ek__BackingField = value;
			}
		}

		public string _sellingprice
		{
			[CompilerGenerated]
			get
			{
				return _003C_sellingprice_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_sellingprice_003Ek__BackingField = value;
			}
		}

		public string _number
		{
			[CompilerGenerated]
			get
			{
				return _003C_number_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_number_003Ek__BackingField = value;
			}
		}

		public string _subtotal
		{
			[CompilerGenerated]
			get
			{
				return _003C_subtotal_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_subtotal_003Ek__BackingField = value;
			}
		}

		public string _discount
		{
			[CompilerGenerated]
			get
			{
				return _003C_discount_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_discount_003Ek__BackingField = value;
			}
		}

		public string _sum
		{
			[CompilerGenerated]
			get
			{
				return _003C_sum_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_sum_003Ek__BackingField = value;
			}
		}

		public string _barcode
		{
			[CompilerGenerated]
			get
			{
				return _003C_barcode_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_barcode_003Ek__BackingField = value;
			}
		}

		public string _cropId
		{
			[CompilerGenerated]
			get
			{
				return _003C_cropId_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_cropId_003Ek__BackingField = value;
			}
		}

		public string _pestId
		{
			[CompilerGenerated]
			get
			{
				return _003C_pestId_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_pestId_003Ek__BackingField = value;
			}
		}

		public string _specialPrice1
		{
			[CompilerGenerated]
			get
			{
				return _003C_specialPrice1_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_specialPrice1_003Ek__BackingField = value;
			}
		}

		public string _specialPrice2
		{
			[CompilerGenerated]
			get
			{
				return _003C_specialPrice2_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_specialPrice2_003Ek__BackingField = value;
			}
		}

		public string _openPrice
		{
			[CompilerGenerated]
			get
			{
				return _003C_openPrice_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_openPrice_003Ek__BackingField = value;
			}
		}

		public string _subsidyMoney
		{
			[CompilerGenerated]
			get
			{
				return _003C_subsidyMoney_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_subsidyMoney_003Ek__BackingField = value;
			}
		}

		public string _subsidyFertilizer
		{
			[CompilerGenerated]
			get
			{
				return _003C_subsidyFertilizer_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_subsidyFertilizer_003Ek__BackingField = value;
			}
		}

		public string _ISWS
		{
			[CompilerGenerated]
			get
			{
				return _003C_ISWS_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_ISWS_003Ek__BackingField = value;
			}
		}

		public string _CLA1NO
		{
			[CompilerGenerated]
			get
			{
				return _003C_CLA1NO_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003C_CLA1NO_003Ek__BackingField = value;
			}
		}

		public GoodObjectWithMoney(int index, CommodityInfo GDSName, string setprice, string sellingprice, string number, string subtotal, string discount, string sum, string barcode, string cropId, string pestId, string specialPrice1, string specialPrice2, string openPrice, string subsidyFertilizer, string subsidyMoney, string ISWS, string CLA1NO)
		{
			_index = index;
			_GDSName = GDSName;
			_setprice = setprice;
			_sellingprice = sellingprice;
			_number = number;
			_subtotal = subtotal;
			_discount = discount;
			_sum = sum;
			_barcode = barcode;
			_cropId = cropId;
			_pestId = pestId;
			_specialPrice1 = specialPrice1;
			_specialPrice2 = specialPrice2;
			_openPrice = openPrice;
			_subsidyFertilizer = subsidyFertilizer;
			_subsidyMoney = subsidyMoney;
			_ISWS = ISWS;
			_CLA1NO = CLA1NO;
		}
	}
}
